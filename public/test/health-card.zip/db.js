const { initializeApp, applicationDefault, cert } = require('firebase-admin/app');
const { getFirestore, Timestamp, FieldValue, Firestore } = require('firebase-admin/firestore');
const serviceAccount = require('./health-card-iot-firebase-adminsdk-8a94h-88187343f3.json');
var CryptoJS = require("crypto-js");
initializeApp({
  credential: cert(serviceAccount)
});

const session = require('./session')

const db = getFirestore();

var UserDetails;

function isValidDoc(a){
    var str="";
    for(var i in a) str+= CryptoJS.SHA256(a[i]).toString();
    var id = CryptoJS.SHA256(str).toString();
    
    return new Promise((resolve,reject)=>{
        db.collection("doctor").doc(id).get()
    .then((res)=>{
        resolve(res.exists);
    }).catch((err)=>reject(undefined));
    })
}

function getAge(dt) {
    var today = new Date();
    var birthDate = dt;
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

function isValidUser(a){
    var str="";
    for(var i in a) str+= CryptoJS.SHA256(a[i]).toString();
    var id = CryptoJS.SHA256(str).toString();
    console.log(id);
    return new Promise((resolve,reject)=>{
        db.collection("user").doc(id).get()
    .then((res)=>{
        if(res.exists){
            var obj = res.data();
            var s = new Date(obj["dob"].toDate());
            obj["age"] = getAge(s);
            obj["dob"] = s.toLocaleDateString();
            session.userD(obj);
        }
        resolve(res.exists);
    }).catch((err)=>reject(undefined));
    })
}




module.exports = {
    isValidDoc : (a)=>isValidDoc(a),
    isValidUser : (a)=>isValidUser(a)
}