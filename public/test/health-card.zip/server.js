const express = require('express');
const appe = express();
const http = require('http');
const server = http.createServer(appe);
const { Server } = require("socket.io");
const db = require('./db');
const { isValidDoc } = require('./db');
const io = new Server(server);
const { app, BrowserWindow, ipcMain } = require("electron");
const session = require('./session');
const { init } = require('./session');

appe.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
  });

appe.get('/doc', (req, res) => {
  res.sendFile(__dirname + '/doctor.html');
});

appe.get('/user', (req, res) => {
    res.sendFile(__dirname + '/user.html');
  });



var Doc;
var User;

var mW;

ipcMain.handle('show-notification', (event, ...args) => {
    const notification = {
        title: 'New Task',
        body: `Added: ${args[0]}`
    }
    mW = event.sender;
    event.sender.send("connection","Connection successful");
  
    // new Notification(notification).show()
  });
  

io.on('connection', (socket) => {
//   console.log('a user connected');
  if(socket.handshake.query["type"]==1){
    Doc = socket.handshake.query["chunks"];
    Doc = Doc.split(',');
  }
  else{
    User = socket.handshake.query["chunks"];
    User = User.split(',');
  }

  db.isValidDoc(Doc).then((res)=>{
    if(Doc==undefined) return;
    console.log(Doc);
    if(res==true){
        if(User==undefined) return;
        console.log(User);
        db.isValidUser(User).then(res2=>{
            if(res2==true){
                
                console.log("BOTH VERIFIED");
                init(Doc,User);
                mW.send("stat","BOTH VERIFIED");
                mW.send("session",true);
            }else if(res2==undefined){
                console.log("PLEASE INSERT USER CARD");
                mW.send("stat","PLEASE INSERT USER CARD");
            }else console.log("INVALID P INFO");
        })
    }else if(res==undefined){
        console.log("PLEASE INSERT DOCTOR CARD");
        mW.send("stat","PLEASE INSERT DOCTOR CARD");
    }else console.log("INVALID D INFO");

  })
  
  socket.on('disconnect', () => {
    // console.log('user disconnected');
    if(socket.handshake.query["type"]==1){
        mW.send("session",false);
            Doc=undefined;
    mW.send("stat","PLEASE INSERT DOCTOR CARD");
      }
      else{
        mW.send("session",false);
            User=undefined;
            mW.send("stat","PLEASE INSERT USER CARD");

      }
  });
});

server.listen(3000, () => {
  
});