const { ipcMain } = require("electron");
const db = require("./db");

var Doc,User;

var UserDetails;

ipcMain.handle("session",(event,args)=>{
    if(Doc==undefined || User==undefined){
        event.sender.send("session",false);
        return;
    }
    event.sender.send("userDetails",UserDetails);

});

ipcMain.handle("change",(event,args)=>{

})

ipcMain.handle("add",(event,args)=>{
    
})

module.exports = {
    init : (a,b) => {Doc=a;User=b},
    userD : (d)=>{UserDetails=d}
}