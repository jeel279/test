const { app, BrowserWindow, ipcMain, Notification } = require("electron");

const server = require('./server')

const path = require("path");

var mW;

const loadMainWindow = () => {
    const mainWindow = new BrowserWindow({
        width : 1200,
        height: 800,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
      enableRemoteModule: true,devTools:true
        }

        
    });


    // mainWindow.setMenu(null);

    mainWindow.loadFile(path.join(__dirname, "main.html"));
}

app.on("ready", loadMainWindow);




app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) {
      loadMainWindow();
  }
});

// ipcMain.handle('show-notification', (event, ...args) => {
//   const notification = {
//       title: 'New Task',
//       body: `Added: ${args[0]}`
//   }
//   mW = event.sender;
//   event.sender.send("signal","communication channel established");

//   // new Notification(notification).show()
// });

function snd(id,data){
  mW.send(id,data);
}

module.exports = {
  snd : (a,b)=>console.log(a,b),
}