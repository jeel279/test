var CryptoJS = require("crypto-js");
var db = require('./db');
var id = "4321413567";
var a = ["432","141","3567"];
var u = ["8779","4682","3084","7823"];
// var a = ["432","1413","567"];
var str="",stru="";
for(var i in a) str+= CryptoJS.SHA256(a[i]).toString();
for(var i in u) stru+= CryptoJS.SHA256(u[i]).toString();
// console.log("STR : "+str);
// console.log("________________________________\n_____________________________");
var hash = CryptoJS.SHA256(str).toString();
var hashu = CryptoJS.SHA256(stru).toString();

db.isValidDoc(hash).then((res)=>{
    console.log(res);
    db.isValidUser(hashu).then((res2)=>{
        console.log(res2);
    }).catch((err2)=>{
        console.log(err2);
    })
}).catch((err)=>{
    console.log(err);
})
